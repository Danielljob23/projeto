package br.inatel.cdg.po;

public class SistemaOperacional {

    String nome;
    int tipo;
}
