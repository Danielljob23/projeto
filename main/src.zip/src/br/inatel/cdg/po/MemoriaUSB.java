package br.inatel.cdg.po;

public class MemoriaUSB {

    String nome;
    int capacidade;
}
