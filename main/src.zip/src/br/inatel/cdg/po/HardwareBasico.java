package br.inatel.cdg.po;

public class HardwareBasico {

     String nome;
     float capacidade;
}
