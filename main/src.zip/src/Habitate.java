public interface Habitate {
    //Método abstrato, implementado por classes que o utilizare
    void espaco();
}
